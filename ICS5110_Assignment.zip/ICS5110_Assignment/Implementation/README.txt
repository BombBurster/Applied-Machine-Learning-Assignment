Explanation of contents for Python files:

	- Function_file.py: Contains all the necessary functions used in Data_Preperation.py, and Training_and_Testing_ML_Models.py
	
	- Data_Preperataions.py: Contains code to prepare the dataset to train and test models.
	
	- Logistic_Regressor.py: Implements the Logistic Regressor from First Principles
	
	- Random_Forest.py: Implements the Random Forest from First Principles
	
	- Training_and_Testing_ML_models.py implements the code to train and test the different implementation of ML models, and output the resulting evaluation metrics.